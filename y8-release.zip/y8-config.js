// Configured Y8 App ID & Game ID
window.CZ_Y8_APP_ID = "6afd7dbb503c198cf6e52081";
window.CZ_Y8_GAME_ID = "293997";
