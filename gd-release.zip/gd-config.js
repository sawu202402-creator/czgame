// Paste your 32-character GameDistribution Game ID below (from developer.gamedistribution.com)
window.CZ_GD_GAME_ID = "";
